N.B. Unnamed semaphores are not supported in OS X

# Scaricare una macchina virtuale a 32bit basata su Debian 
# con Xfce 4 e gcc version 4.4.5 dal seguente indirizzo:

https://drive.google.com/file/d/1vv86ULlAfHciyS9a1SBEuYRV-NqtELiZ/view?usp=sharing

# da avviare con un software di virtualizzazione (e.g. Virtual Box)

# CREDENZIALI:
# nome_utente: root
# password: infob



# In alternativa: https://ideone.com/
# ma tenere in considerazione che non consente output parziali
# o esecuzione di software per un prolungato periodo di tempo