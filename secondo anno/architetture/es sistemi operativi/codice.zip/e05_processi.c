#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>


int main(void) {
    printf("Ciao!\n");
    pid_t pid1 = fork();
    printf("Ciao!\n");
    if (pid1 == 0) {
        fork();
        printf("Ciao!\n");
    } else {
        printf("Ciao!\n");
    }
    fork();
    printf("Ciao!\n");
    return 0;
}