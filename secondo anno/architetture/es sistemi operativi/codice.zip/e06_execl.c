#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>


int main(void) {
    printf("Ciao!\n");
    pid_t pid1 = fork();
    printf("Ciao!\n");
    if (pid1 == 0) { // codice eseguito dal figlio Q
        printf("Figlio\n");
        execl("./e04_prod_cons.o", NULL);
    } else { // codice eseguito dal padre
        printf("Padre\n");
        execl("./e04_prod_cons.o", NULL);
    }
    return 0;
}