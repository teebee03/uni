#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define N_TH 1

char buffer;
int fine = 0;
sem_t pieno, vuoto;

void *scrivi(void *arg) {
    int i,j;
    for (i = 0; i < 5; i++) {
        for(j = 0; j < N_TH; j++) // Tutti i lettori devono aver letto
            sem_wait(&vuoto);
        buffer = 'a' + i;
        printf("===> Ho scritto '%c'\n", buffer);
        for(j = 0; j < N_TH; j++) // Comunico a tutti i lettori che possono leggere
            sem_post(&pieno);
    }
    fine = 1;
    return NULL;
}

void *leggi(void *mytID) {
    while (fine == 0){
        sem_wait(&pieno); // Posso leggere un nuovo carattere
        printf("Thread %d: ho letto '%c'\n", (int) mytID, buffer);
        sem_post(&vuoto); // Carattere letto
    }
    int i;
    sem_getvalue(&pieno, &i);
    if(i == 1)
        printf("Thread %d: ho letto '%c'\n", (int) mytID, buffer);
    return NULL;
}

int main(void) {

    int i;
    sem_init(&pieno, 0, 0);
    sem_init(&vuoto, 0, N_TH);

    pthread_t th1, ths[N_TH];

    pthread_create(&th1, NULL, scrivi, (void *) -1);

    for (i = 0; i < N_TH; i++)
        pthread_create(&ths[i], NULL, leggi, (void *) i);

    for (i = 0; i < N_TH; i++)
        pthread_join(ths[i], NULL);

    pthread_join(th1, NULL);

    return 0;

}