#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define N_TH 1

char buffer;
int fine = 0;

void *scrivi(void *arg) {
    int i;
    for (i = 0; i < 5; i++) {
        buffer = 'a' + i;
        printf("===> Ho scritto '%c'\n", buffer);
    }
    fine = 1;
    return NULL;
}

void *leggi(void *mytID) {
    while (fine == 0){
        printf("Thread %d: ho letto '%c'\n", (int) mytID, buffer);
    }
    return NULL;
}

int main(void) {

    int i;

    pthread_t th1, ths[N_TH];

    pthread_create(&th1, NULL, scrivi, NULL);

    for (i = 0; i < N_TH; i++)
        pthread_create(&ths[i], NULL, leggi, (void *) i);

    for (i = 0; i < N_TH; i++)
        pthread_join(ths[i], NULL);

    pthread_join(th1, NULL);

    return 0;

}